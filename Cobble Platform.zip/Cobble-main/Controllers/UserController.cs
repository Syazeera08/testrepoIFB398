﻿using Microsoft.AspNetCore.Mvc;
using System.Data;
using System.Data.SqlClient;
using System.Collections.Generic;
using Microsoft.Extensions.Configuration;
using Cobble.Models;
using System.Reflection.PortableExecutable;
using Microsoft.AspNetCore.Session;
using Microsoft.AspNetCore.Http;
using static Cobble.SessionVariables;
using System.Text.Json;
using System.Net;



// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace Cobble.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class UserController : ControllerBase
    {
        private readonly IConfiguration _configuration;
        public UserController(IConfiguration configuration)
        {
            _configuration = configuration;
        }

        [HttpPost]
        [Route("register")]
        [ProducesResponseType(StatusCodes.Status202Accepted)] //Status returned to the front end
        [ProducesResponseType(StatusCodes.Status403Forbidden)]
        public ContentResult register(User user) //user refers to post content
        {
            SqlConnection con = new SqlConnection(_configuration.GetConnectionString("CobbleLogin").ToString());

            SqlCommand cmd = new SqlCommand("INSERT INTO glb_Users(UserName, Password, UserPoints, PostDate) VALUES('" + user.UserName + "','" + user.Password + "', 0, '"+ DBNull.Value + "')", con);
            con.Open();//Connect to the database
            int i = 0;
            try { // i changed some code here, the error was with datetime handling again, needs to be looked into as right now every account will be made in 1900.
                 i = cmd.ExecuteNonQuery(); //Execute database instructions
            }
            catch (WebException res){
                return new ContentResult { Content = JsonSerializer.Serialize(res.Message), StatusCode = 500 };
            }
            con.Close();
            if (i > 0)
            {
                return new ContentResult { Content = JsonSerializer.Serialize("register succeed"), StatusCode = 201 };
            }
            else
            {
                return new ContentResult { Content = JsonSerializer.Serialize("register fail"), StatusCode = 403 };
            }
        }

        [HttpPost]
        [Route("login")]
        [ProducesResponseType(StatusCodes.Status202Accepted)]
        [ProducesResponseType(StatusCodes.Status403Forbidden)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        public ContentResult login(User user)
        {
            SqlConnection con = new SqlConnection(_configuration.GetConnectionString("CobbleLogin").ToString());
            SqlCommand cmd = new SqlCommand("SELECT * FROM glb_Users WHERE UserName = '" + user.UserName + "';", con);
            con.Open();
            SqlDataReader read = cmd.ExecuteReader();
            var result = new List<User>(); //Convert the previous step read into result
            while (read.Read())
            {
                User a_user = new User
                {
                    UserName = read.GetString(1),
                    Password = read.GetString(2),
                };
                result.Add(a_user);
            };
            read.Close();
            con.Close();
            if (!result.Any())
            {
                return new ContentResult { Content = JsonSerializer.Serialize("user not found"), StatusCode = 404 };//Database return is empty
            }

            foreach (var a_user in result)
            {
                if (a_user.Password == user.Password) //verify password
                {
                    HttpContext.Session.SetString(SessionVariables.SessionKeyUserEmail.ToString(), a_user.UserName);
                    //HttpContext.Session.SetString(SessionKeyEnum.SessionKeyUserGroup.ToString(), a_user.Group);
                    return new ContentResult { Content = JsonSerializer.Serialize(HttpContext.Session.GetString(SessionVariables.SessionKeyUserEmail)), StatusCode = 202 };
                }
            }
            return new ContentResult { Content = JsonSerializer.Serialize("incorrect password"), StatusCode = 403 };
        }

        [HttpGet]
        [Route("logout")]
        [ProducesResponseType(StatusCodes.Status202Accepted)]
        [ProducesResponseType(StatusCodes.Status403Forbidden)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        public ContentResult logout()
        {
            HttpContext.Session.SetString(SessionVariables.SessionKeyUserEmail.ToString(), "no_user");
            return new ContentResult { Content = JsonSerializer.Serialize("logged out"), StatusCode = 202 };
            
        }

        [HttpGet]
        [Route("checkLogin")]
        [ProducesResponseType(StatusCodes.Status202Accepted)] //Status returned to the front end
        [ProducesResponseType(StatusCodes.Status204NoContent)]
        public ContentResult checkLogin()
        {
            string currentUser = HttpContext.Session.GetString(SessionVariables.SessionKeyUserEmail);
            if (currentUser != null && currentUser != "no_user")
            {
                return new ContentResult { Content = JsonSerializer.Serialize(currentUser), StatusCode = 202 };
            }
            else
            {
                return new ContentResult { Content = JsonSerializer.Serialize("no logged in user"), StatusCode = 204 };

            }
        }
    }
}
