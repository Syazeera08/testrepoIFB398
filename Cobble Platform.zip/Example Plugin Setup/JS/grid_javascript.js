
currentUser = null

window.onload = function () {
    switchPage('mainPage')
}


function switchPage(name) {
    var pages = document.getElementsByClassName("pages");
    var shownPage = document.getElementById(name);
    for (var i = 0; i < pages.length; i++) {
        pages[i].style.display = "none";
    }
    shownPage.style.display = "block";
}

function switchInnerPage(name) {
    var pages = document.getElementsByClassName("innerPages");
    var shownPage = document.getElementById(name);
    for (var i = 0; i < pages.length; i++) {
        pages[i].style.display = "none";
    }
    shownPage.style.display = "block";
}

function ModuleCheck(){
    fetch("/api/Module/Check", {
        referer: 'about:client',
        credentials: 'same-origin',
        headers: new Headers({ 'content-type': 'application/ json' }),
    })
        .then(function (response) {
            if (response.status == 200) {
                response.json()
                    .then(data => {
                        var innerPagesDiv = document.getElementById("innerPagesDiv");
                        var switchInnerPageButtons = document.getElementById("switchInnerPageButtons")


                        for (var i = 0; i < data.length; i++) {
                            innerPagesDiv.insertAdjacentHTML("beforeend", data[i]);
                            var newInnerPage = document.getElementsByClassName("innerPages")
                            console.log(newInnerPage)
                            switchInnerPageButtons.insertAdjacentHTML("beforeend", " <a onclick=" + '"' + "switchInnerPage('" + newInnerPage[newInnerPage.length - 1].id + "')" + '"' + " >" + newInnerPage[newInnerPage.length - 1].getAttribute("nameonbutton") +"</a>")
                        }
           
                        var scripts = document.getElementsByTagName("script")
                        for (i = 0; i < scripts.length; i++) {
                            const importScript = document.createElement("script")
                            importScript.setAttribute("src", scripts[i].src);
                            scripts[i].remove();
                            document.head.appendChild(importScript)
                        }
                    })
            } else {

            }

        }
        ).catch(function (err) {

        })
}


function ModuleList() {
    fetch("/api/Module/List", {
        referer: 'about:client',
        credentials: 'same-origin',
        headers: new Headers({ 'content-type': 'application/ json' }),
    })

        .then(function (response) {
            if (response.status == 200) {
                response.json()
                    .then(data => {
                        moduleList = document.getElementById("moduleList")
                        for (var i = 0; i < data.length; i++) {
                            moduleList.insertAdjacentHTML("beforeend", "<div class= 'card' ><div class='card-header'>" + data[i].ModuleCode + "<button type = 'button' class='btn btn-danger float-end' onclick =" + '"ModuleDelete(' + "'" + data[i]._Module + "'"+')"'+">Delete</button> </div><div class='card-body'>" + data[i].Description + "</div> </div> ")
                        }
                    })
            } else {

            }

        }
        ).catch(function (err) {

        })
}

function ModuleDelete(name) {
    const data = JSON.stringify({
        '_Module': name,
        "ModuleCode": "",
        "Description": "",
        "SecurityLevel": 0,
    })
    fetch("/api/Module/Delete", {
        method: 'POST',
        referer: 'about:client',
        credentials: 'same-origin',
        headers: new Headers({ 'content-type': 'application/ json' }),
        body: data,
    })
        .then(function (response) {
            if (response.status == 200) {
                response.json()
                    .then( ()=> {
                        moduleList = document.getElementById("moduleList")
                        moduleList.innerHTML = '<h1 class="text-center pb-4"><img src="images/Bee.png" width="100" height="100" alt="Bee Aware Platform">Delete Plugins</h1>'
                        ModuleList()
                    })
            } else {

            }

        }
        ).catch(function (err) {

        })
}

function uploadModule(event) {
    event.stopImmediatePropagation();
    event.preventDefault();
    const formData = new FormData;
    var file = document.getElementById("uploadFile").files[0];
    formData.append('FileName', file.name.substr(0, file.name.lastIndexOf('.')));
    formData.append('file', file);

    fetch("/api/Upload/UploadModule", {
        referer: 'about:client',
        credentials: 'same-origin',
        method: 'POST',
        body: formData
    })
        .then(function (response) {
            if (response.status == 201) {
                response.json()
                    .then(data => {
                        window.alert("uploaded")
                    })
            } else {
                window.alert("failed!!")
            }

        }
        ).catch(function (err) {

        })
};





function columnStyleOne() {
	let classes = document.querySelectorAll(".col");
	for (let i = 0; i < classes.length; i++) {
		classes[i].style.backgroundColor = "#FEE280";
		classes[i].style.margin = "20px";
		classes[i].style.padding = "20px";
		classes[i].style.boxShadow = "5px 5px #3F2704";
		classes[i].style.borderRadius = "5px";
		classes[i].style.border = "0px";
	}
	classes = document.querySelectorAll(".col-6");
	for (let i = 0; i < classes.length; i++) {
		classes[i].style.backgroundColor = "#FEE280";
		classes[i].style.margin = "20px";
		classes[i].style.padding = "20px";
		classes[i].style.boxShadow = "5px 5px #3F2704";
		classes[i].style.borderRadius = "5px";
		classes[i].style.border = "0px";
	}
}

function columnStyleTwo() {
	let classes = document.querySelectorAll(".col");
	for (let i = 0; i < classes.length; i++) {
		classes[i].style.backgroundColor = "white";
		classes[i].style.border = "1px solid black";
		classes[i].style.boxShadow = "0 0";
		classes[i].style.borderRadius = "0px";

	}
	classes = document.querySelectorAll(".col-6");
	for (let i = 0; i < classes.length; i++) {
		classes[i].style.backgroundColor = "white";
		classes[i].style.border = "1px solid black";
		classes[i].style.boxShadow = "0 0";
		classes[i].style.borderRadius = "0px";
	}
}