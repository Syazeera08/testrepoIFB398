document.addEventListener("DOMContentLoaded", function () {
    const darkModeToggle = document.getElementById("darkModeToggle");
    const body = document.body;

    // Check for a stored dark mode preference in local storage
    const isDarkMode = localStorage.getItem("darkMode");

    // Set dark mode based on the stored preference or user input
    if (isDarkMode === "enabled") {
        enableDarkMode();
    } else if (isDarkMode === "disabled") {
        disableDarkMode();
    }

    darkModeToggle.addEventListener("change", () => {
        if (darkModeToggle.checked) {
            enableDarkMode();
        } else {
            disableDarkMode();
        }
    });

    function enableDarkMode() {
        body.classList.add("dark-mode");
        localStorage.setItem("darkMode", "enabled");
    }

    function disableDarkMode() {
        body.classList.remove("dark-mode");
        localStorage.setItem("darkMode", "disabled");
    }
});
